<div class="page-wrapper">          
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-lg col-xlg-3 p-t-20">
                <div class="card card-hover">
                    <div class="box bg-white text-center">
                        <h1 class="font-light text-white"></h1>
                        <h6 class="text-black">CHÀO MỪNG ĐẾN VỚI HỆ THỐNG QUẢN TRỊ WEBSITE ĐẶT VÉ XEM PHIM</h6>
                    </div>
                </div>
            </div>
        </div>

    </div>