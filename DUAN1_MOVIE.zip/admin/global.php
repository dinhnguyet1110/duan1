<?php
    $avatar_path="../admin/upload/";
?>