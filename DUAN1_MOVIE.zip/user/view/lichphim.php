
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        function callAPI() {
            console.log("da goi duoc api!")
            $.ajax({
                url: "/user/view/data.php",
                type: 'GET',
                
                success: function (data) {
                    console.log("data: "+data)
                    $("#gio_chieu").html("");
                    data.forEach(gio_chieu => {
                        $("#gio_chieu").append("<option value=" + '"' + gio_chieu + '"' + ">" + gio_chieu + "</option>")
                    });
                },
                error: function(error){
                    // alert(error)
                }
            })
        }
        $(document).ready(function() {
            $('#ngay_chieu').on('change', function() {
                // alert( this.value ); // or $(this).val()
                callAPI();
            });
        });
    </script>
    <section class="movie-section padding-top padding-bottom">
        <div class="container">
            <div class="section-header-2 pt-50">
                    <div class="left">
                        <h4 class="title">Chọn Lịch xem phim</h4>
                       
                    </div>
                    
                </div>
        <form method="post" action="index.php?act=phong&id='.$gio_chieu['id'].'">
            <br>
            <p>Chọn ngày xem phim (yyyy-MM-dd)</p>
                <select class="form-control form-control-lg" name="ngay_chieu" id="ngay_chieu">                                              
                    <?php
                        foreach($khunggio as $ngay){
                            extract($ngay);
                            echo '<option value="'.$ngay['id'].'" >'.$ngay_chieu.'</option>';
                        }
                    ?>                                      
                </select>
                    
            <br>
            
            <p>Chọn giờ xem phim (HH:mm)</p>
                <select class="form-control form-control-lg" name="gio_chieu" id="gio_chieu">    
                                                        
                    <?php
                        foreach($khunggio as $gio){
                            extract($gio);
                            echo '<option value="'.$gio['id_lichchieu'].'" >'.$gio_chieu.'</option>';
                        }
                    ?>                                      
                </select>
            <br><br>
            <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">

            </a href="index.php?act=phong&id=".$id><input type="submit" class="btn btn-outline-danger btn-block" value="Chọn"></a>
        </form>
            
        </div>
    </section>

    