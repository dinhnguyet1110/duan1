
    
    
    <section class="movie-section padding-top padding-bottom">
        <div class="container">
            <div class="section-header-2 pt-50">
                    <div class="left">
                        <h4 class="title">Chọn phòng </h4>
                       
                    </div>
                    
                </div>
            <div class="tab row">  
                <?php foreach($listphong as $phong) : ?>
                <?php extract($phong) ?>                         
                    <!-- <div class="tab-item active">
                        <div class="owl-carousel owl-theme tab-slider">  -->
                            <div class="item">                          
                                <div class="movie-grid">                                                              
                                    <div class="movie-thumb bg-one">
                                        <a href="index.php?act=chon_ghe&id=<?php echo $id ?>">
                                          
                                        </a>
                                    </div>
                                    <div class="movie-content bg-one">
                                        <h5 class="title m-0">                                      
                                        <a href="">
                                         <?php echo $ten_phong ?></a>                                           
                                        </h5>
                                                                              
                                    </div>  
                                    <a href="index.php?act=chon_ghe&id=<?php echo $id ?>" class="btn btn-outline-danger btn-block">Chọn</a>                             
                                </div>                                   
                            </div>                         
                        <!-- </div>
                    </div> --> 
                <?php endforeach ?>

            </div>
            
        </div>
    </section>