
<section class="details-banner hero-area bg_img seat-plan-banner" data-background="assets/images/banner/banner04.jpg">
        <div class="container">
            <div class="details-banner-wrapper">
                <div class="details-banner-content style-two">
                    <h3 class="title" >Chọn ghế </h3>
                    
                </div>
            </div>
        </div>
    </section>
    <!-- ==========Banner-Section========== -->

    <!-- ==========Page-Title========== -->
    <section class="page-title bg-one">
        <div class="container">
            <div class="page-title-area">
                <div class="item md-order-1">
                    <a href="index.php?act=phong" class="custom-button back-button">
                        <i class="flaticon-double-right-arrows-angles"></i>back
                    </a>
                </div>
                <div class="item date-item">
                    <!-- <span class="date">MON, SEP 09 2020</span>
                    <select class="select-bar">
                        <option value="sc1">09:40</option>
                        <option value="sc2">13:45</option>
                        <option value="sc3">15:45</option>
                        <option value="sc4">19:50</option>
                    </select> -->
                </div>
                <div class="item">
                   
                </div>
            </div>
        </div>
    </section>

    <div class="seat-plan-section padding-bottom padding-top">
        <div class="container">
            <div class="screen-area">
                <h4 class="screen">Màn hình</h4>
                <div class="screen-thumb">
                    <img src="assets/images/movie/screen-thumb.png" alt="movie">
                </div>
                    <div class="screen-wrapper">
                    <div class="seats-container">
                        <!-- Seats will be dynamically added here using JavaScript -->
                    </div>
                        <div class="button-container">
                            <button onclick="bookSeats()">Đặt Ghế</button>
                        </div>
                    
                        <script>
                            document.addEventListener('DOMContentLoaded', function () {
                                createSeats();
                            });

                            function createSeats() {
                                const seatsContainer = document.querySelector('.seats-container');
                                const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
                                for (let row of rows) {    
                                    for (let i = 1; i <= 10; i++) {
                                const seat = document.createElement('div');
                                seat.classList.add('seat');
                                seat.dataset.seatNumber = `${row}${i}`;
                                seat.innerText = seat.dataset.seatNumber;
                                seat.addEventListener('click', function () {
                                    if (!seat.classList.contains('booked')) {
                                        seat.classList.toggle('selected');
                                    }
                                });

                                // Đặt màu đặc biệt cho hàng F và G
                                if (row === 'F' || row === 'G') {
                                    seat.classList.add('row-FG');
                                }

                                seatsContainer.appendChild(seat);
                                    }
                                }

                                // Mô phỏng một số ghế đã đặt
                                const bookedSeats = ['A1', 'C3', 'D5', 'F8', 'G10'];
                                bookedSeats.forEach(seatNumber => {
                                    const seat = document.querySelector(`.seat[data-seat-number="${seatNumber}"]`);
                                    seat.classList.add('booked');
                                });
                                }

                                function bookSeats() {
                                    const selectedSeats = document.querySelectorAll('.seat.selected');
                                    if (selectedSeats.length > 0) {
                                        let totalPrice = 0;

                                        selectedSeats.forEach(seat => {
                                            // Kiểm tra xem ghế có thuộc hàng F hoặc G không
                                            const isRowFOrG = seat.classList.contains('row-FG');

                                            // Điều chỉnh giá dựa trên hàng của ghế
                                            totalPrice += isRowFOrG ? 80000 : 60000;
                                        });

                                        alert(`Đã đặt các ghế: ${Array.from(selectedSeats).map(seat => seat.dataset.seatNumber).join(', ')}\nTổng giá: ${totalPrice} VND`);
                                    } else {
                                        alert('Vui lòng chọn ít nhất một ghế để đặt.');
                                    }
                                }
                        </script>
                    </div>
                    
                </div>
            <?php ?>
            
        </div>
    </div>
    <style>
        .seats-container {
            display: grid;
            grid-template-columns: repeat(10, 1fr);
            gap: 10px;
        }

        .seat {
            width: 50px;
            height: 50px;
            margin-bottom: 10px;
            background-color: #ced4da;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            user-select: none;
        }

        .seat.booked {
            background-color: #dc3545;
            cursor: not-allowed;
        }

        .seat.selected {
            background-color: #28a745;
        }

        .seat.row-F,
        .seat.row-G {
            background-color: #ffc107; /* Màu ghế đặc biệt cho hàng F và G */
        }

        .button-container {
            margin-top: 20px;
        }

        button {
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
            outline: none;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>